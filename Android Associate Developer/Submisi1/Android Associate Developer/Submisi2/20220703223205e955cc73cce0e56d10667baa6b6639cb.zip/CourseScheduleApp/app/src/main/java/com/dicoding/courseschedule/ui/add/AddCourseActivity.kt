package com.dicoding.courseschedule.ui.add

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.courseschedule.R
import com.dicoding.courseschedule.ui.list.ListViewModelFactory
import com.dicoding.courseschedule.util.TimePickerFragment
import java.text.SimpleDateFormat
import java.util.*

class AddCourseActivity : AppCompatActivity(), TimePickerFragment.DialogTimeListener {
    private lateinit var viewModel: AddCourseViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_course_activity)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.add_course)

        val fac = ListViewModelFactory.createFactory(this)
        viewModel = ViewModelProvider(this, fac).get(AddCourseViewModel::class.java)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_insert -> {
                val editCourse = findViewById<TextView>(R.id.tv_course_name)
                val editLecturer = findViewById<TextView>(R.id.tv_lecturer)
                val editNote = findViewById<TextView>(R.id.tv_note)
                val spinner = findViewById<Spinner>(R.id.spinner2)

                val cour = editCourse.text.toString().trim()
                val lect = editLecturer.text.toString().trim()
                val note = editNote.text.toString().trim()
                val day = spinner.selectedItemPosition
                val start = findViewById<TextView>(R.id.add_tv_start_time).text.toString()
                val end = findViewById<TextView>(R.id.add_tv_end_time).text.toString()

                if (cour.isNotEmpty() && lect.isNotEmpty() && note.isNotEmpty()) {
                    viewModel.insertCourse(
                        courseName = cour,
                        day = day,
                        startTime = start,
                        endTime = end,
                        lecturer = lect,
                        note = note
                    )
                    finish()
                } else {
                    Toast.makeText(this, getString(R.string.empty_list_message), Toast.LENGTH_SHORT)
                        .show()
                }

                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun showTimePickerStartTime(view: View) {
        val dialogFragment = TimePickerFragment()
        dialogFragment.show(supportFragmentManager, "startPicker")
    }

    fun showTimePickerEndTime(view: View) {
        val dialogFragment = TimePickerFragment()
        dialogFragment.show(supportFragmentManager, "endPicker")
    }

    override fun onDialogTimeSet(tag: String?, hour: Int, minute: Int) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        if (tag == "startPicker") {
            findViewById<TextView>(R.id.add_tv_start_time).text = dateFormat.format(cal.time)
        } else {
            findViewById<TextView>(R.id.add_tv_end_time).text = dateFormat.format(cal.time)
        }
    }
}