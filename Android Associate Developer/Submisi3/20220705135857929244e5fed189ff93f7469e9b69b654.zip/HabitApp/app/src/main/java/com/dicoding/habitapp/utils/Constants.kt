package com.dicoding.habitapp.utils

const val HABIT = "HABIT"
const val HABIT_ID = "HABIT_ID"
const val HABIT_TITLE = "HABIT_TITLE"
const val NOTIFICATION_CHANNEL_ID = "notify-channel"
const val NOTIF_UNIQUE_WORK: String = "NOTIF_UNIQUE_WORK"

